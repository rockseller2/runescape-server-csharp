public abstract class Class131_Sub7 extends Class131
{
    public int anInt3691;
    public int anInt3692;
    public static int anInt3693;
    public static int anInt3694;
    public int anInt3695 = -1000;
    public int anInt3696;
    public int[] anIntArray3697;
    public static boolean[] aBooleanArray3698 = new boolean[112];
    public boolean aBoolean3699;
    public int anInt3700;
    public int anInt3701;
    public static int anInt3702;
    public static int anInt3703;
    public int anInt3704;
    public static int anInt3705;
    public int anInt3706;
    public int anInt3707;
    public int anInt3708;
    public static int anInt3709;
    public static int anInt3710 = 0;
    public byte[] aByteArray3711;
    public int anInt3712;
    public int anInt3713;
    public int anInt3714;
    public int anInt3715;
    public int anInt3716;
    public int anInt3717;
    public int anInt3718;
    public int[] smallX;
    public int anInt3720;
    public int anInt3721;
    public int anInt3722;
    public RSString aRSString_3723;
    public static int anInt3724;
    public static int anInt3725;
    public int anInt3726;
    public int anInt3727;
    public int playerAnims = -1;
    public static int anInt3729;
    public static int anInt3730;
    public int anInt3731;
    public Class61_Sub1 aClass61_Sub1_3732;
    public int anInt3733;
    public int anInt3734;
    public int anInt3735;
    public static RSString aRSString_3736
	= Class134.method1914("Texturen geladen)3", (byte) 95);
    public int anInt3737;
    public int anInt3738;
    public int anInt3739;
    public int anInt3740;
    public int anInt3741;
    public int anInt3742;
    public int anInt3743;
    public static int anInt3744;
    public int anInt3745;
    public int anInt3746;
    public Object anObject3747;
    public static int anInt3748;
    public Class21[] aClass21Array3749;
    public int anInt3750;
    public boolean aBoolean3751;
    public static int anInt3752;
    public int anInt3753;
    public int anInt3754;
    public static int anInt3755;
    public int anInt3756;
    public int anInt3757;
    public int anInt3758;
    public int anInt3759;
    public int anInt3760;
    public int anInt3761;
    public int anInt3762;
    public int[] anIntArray3763;
    public int anInt3764;
    public int anInt3765;
    public int anInt3766;
    public static int[] anIntArray3767;
    public static volatile int anInt3768 = 0;
    public int anInt3769;
    public static Class67_Sub5_Sub19_Sub1 aClass67_Sub5_Sub19_Sub1_3770;
    public int anInt3771;
    public boolean aBoolean3772;
    public int anInt3773;
    public int[] anIntArray3774;
    public int anInt3775;
    public int anInt3776;
    public int anInt3777;
    public int anInt3778;
    public boolean aBoolean3779;
    public int anInt3780;
    public int anInt3781;
    public int anInt3782;
    public int anInt3783;
    public int anInt3784;
    public int anInt3785;
    public int[] smallY;
    public int anInt3787;
    public int anInt3788;
    public int anInt3789;
    public static int anInt3790;
    public int anInt3791;
    public int anInt3792;
    public int anInt3793;
    
    public static int method1870(int arg0, int arg1) {
	anInt3725++;
	if (arg1 != -13520)
	    method1875(-48, -113, 98, 94, 26, -69, -46, 83, 16, 15, -73);
	int i = 0x3f & arg0;
	int i_0_ = 0x3 & arg0 >> -926622810;
	if ((i ^ 0xffffffff) != -19) {
	    if (i == 19 || (i ^ 0xffffffff) == -22) {
		if ((i_0_ ^ 0xffffffff) == -1)
		    return 16;
		if ((i_0_ ^ 0xffffffff) == -2)
		    return 32;
		if ((i_0_ ^ 0xffffffff) == -3)
		    return 64;
		if ((i_0_ ^ 0xffffffff) == -4)
		    return 128;
	    }
	} else {
	    if ((i_0_ ^ 0xffffffff) == -1)
		return 1;
	    if ((i_0_ ^ 0xffffffff) == -2)
		return 2;
	    if (i_0_ == 2)
		return 4;
	    if (i_0_ == 3)
		return 8;
	}
	return 0;
    }
    
    public void method1871(int arg0) {
	if (arg0 != 2)
	    method1885(-75, -18, -128, -115, 111, null, -92, -107L, false);
	anInt3727 = 0;
	anInt3709++;
	anInt3713 = 0;
    }
    
    public static void method1872(byte arg0) {
	int i = 28 % ((arg0 - -34) / 48);
	aRSString_3736 = null;
	aBooleanArray3698 = null;
	anIntArray3767 = null;
	aClass67_Sub5_Sub19_Sub1_3770 = null;
    }
    
    public void method1873(int arg0, Class131_Sub6 arg1, boolean arg2) {
	anInt3790++;
	Class131.anInt2425 = 0;
	Class102.anInt2005 = 0;
	Class124.anInt2324 = 0;
	Class87 class87 = method1880((byte) -45);
	int i = class87.anInt1791;
	int i_1_ = class87.anInt1778;
	if (i != 0 && (i_1_ ^ 0xffffffff) != -1) {
	    int i_2_ = Class26.anIntArray612[arg0];
	    int i_3_ = -i / 2;
	    int i_4_ = -i_1_ / 2;
	    int i_5_ = Class26.anIntArray617[arg0];
	    int i_6_ = i_4_ * i_5_ + i_3_ * i_2_ >> -1075854864;
	    int i_7_ = i / 2;
	    int i_8_ = -i_1_ / 2;
	    int i_9_ = -(i_7_ * i_5_) + i_2_ * i_8_ >> -733817936;
	    int i_10_ = i_8_ * i_5_ + i_2_ * i_7_ >> -6514352;
	    int i_11_ = -(i_3_ * i_5_) + i_4_ * i_2_ >> -1760975184;
	    int i_12_
		= Class131_Sub5.method1826(Canvas_Sub1.anInt59,
					   anInt3733 - -i_6_,
					   i_11_ + anInt3726, (byte) -34);
	    int i_13_
		= Class131_Sub5.method1826(Canvas_Sub1.anInt59,
					   i_10_ + anInt3733, i_9_ + anInt3726,
					   (byte) -111);
	    int i_14_ = -i / 2;
	    int i_15_ = i_1_ / 2;
	    int i_16_ = i_14_ * i_2_ + i_15_ * i_5_ >> 921568016;
	    int i_17_ = -(i_5_ * i_14_) + i_15_ * i_2_ >> -1319410032;
	    int i_18_
		= Class131_Sub5.method1826(Canvas_Sub1.anInt59,
					   anInt3733 - -i_16_,
					   anInt3726 + i_17_, (byte) 105);
	    int i_19_ = i / 2;
	    int i_20_ = i_1_ / 2;
	    int i_21_ = i_2_ * i_20_ - i_5_ * i_19_ >> -806696336;
	    int i_22_ = i_19_ * i_2_ + i_20_ * i_5_ >> 977596208;
	    int i_23_
		= Class131_Sub5.method1826(Canvas_Sub1.anInt59,
					   anInt3733 + i_22_,
					   i_21_ + anInt3726, (byte) -109);
	    int i_24_
		= (i_13_ ^ 0xffffffff) >= (i_12_ ^ 0xffffffff) ? i_13_ : i_12_;
	    int i_25_ = i_13_ >= i_23_ ? i_23_ : i_13_;
	    int i_26_ = i_23_ <= i_18_ ? i_23_ : i_18_;
	    Class124.anInt2324
		= (int) (325.95 * Math.atan2((double) (-i_26_ + i_24_),
					     (double) i_1_)) & 0x7ff;
	    int i_27_
		= (i_18_ ^ 0xffffffff) >= (i_12_ ^ 0xffffffff) ? i_18_ : i_12_;
	    if ((Class124.anInt2324 ^ 0xffffffff) != -1)
		arg1.method1847(Class124.anInt2324);
	    Class131.anInt2425
		= (int) (325.95 * Math.atan2((double) (-i_25_ + i_27_),
					     (double) i)) & 0x7ff;
	    if ((Class131.anInt2425 ^ 0xffffffff) != -1)
		arg1.method1836(Class131.anInt2425);
	    Class102.anInt2005 = i_23_ + i_12_;
	    if (i_13_ - -i_18_ < Class102.anInt2005)
		Class102.anInt2005 = i_13_ - -i_18_;
	    Class102.anInt2005
		= -anInt3715 + (Class102.anInt2005 >> -382435711);
	    if (Class102.anInt2005 != 0)
		arg1.method1837(0, Class102.anInt2005, 0);
	}
	if (arg2 != true)
	    aBoolean3699 = false;
    }
    
    public static void method1874(int arg0, int arg1, int arg2) {
	Class67_Sub5_Sub3 class67_sub5_sub3
	    = Class103.method1558(arg2, false, 7);
	class67_sub5_sub3.method846(true);
	class67_sub5_sub3.anInt4491 = arg0;
	if (arg1 < 107)
	    method1879((byte) 20);
	anInt3705++;
    }
    
    public static void method1875(int arg0, int arg1, int arg2, int arg3,
				  int arg4, int arg5, int arg6, int arg7,
				  int arg8, int arg9, int arg10) {
	anInt3729++;
	int i = -arg2 + arg8;
	if (arg8 < Class131_Sub5.anInt3656)
	    i++;
	int i_28_ = -arg5 + arg0;
	if ((Class67_Sub1_Sub13.anInt4031 ^ 0xffffffff) < (arg0 ^ 0xffffffff))
	    i_28_++;
	if (arg4 != 16777215)
	    method1885(-97, 43, 13, -107, 123, null, 4, -121L, true);
	for (int i_29_ = 0; i_28_ > i_29_; i_29_++) {
	    int i_30_ = (1 + i_29_) * arg9 + arg10 >> -322851888;
	    int i_31_ = arg10 + i_29_ * arg9 >> -112912176;
	    int i_32_ = -i_31_ + i_30_;
	    if ((i_32_ ^ 0xffffffff) < -1) {
		int i_33_ = arg5 + i_29_ >> 566939046;
		if ((i_33_ ^ 0xffffffff) > -1
		    || ((i_33_ ^ 0xffffffff)
			< (Class120.anIntArrayArrayArray2287.length - 1
			   ^ 0xffffffff))) {
		    i_30_ += arg3;
		    i_31_ += arg3;
		    for (int i_34_ = 0; i_34_ < i; i_34_++) {
			int i_35_;
			if ((Class114.aClass67_Sub5_Sub6_2155.anInt4543
			     ^ 0xffffffff)
			    == 0) {
			    if ((arg5 + i_29_ & 0x4 ^ 0xffffffff)
				!= (0x4 & i_34_ + arg2 ^ 0xffffffff))
				i_35_ = 4936552;
			    else
				i_35_ = (Class67_Sub1_Sub16_Sub1.anIntArray5098
					 [Class67_Sub1_Sub37.anInt4402 - -1]);
			} else
			    i_35_ = Class114.aClass67_Sub5_Sub6_2155.anInt4543;
			if ((i_35_ ^ 0xffffffff) == -1)
			    i_35_ = 1;
			int i_36_ = (i_34_ * arg1 + arg6 >> 553405392) - -arg7;
			int i_37_
			    = arg7 + (arg6 + arg1 * (i_34_ - -1) >> 297490384);
			int i_38_ = -i_36_ + i_37_;
			Class121.method1683(i_31_, i_36_, i_32_, i_38_, i_35_);
		    }
		} else {
		    i_30_ += arg3;
		    int[][] is = Class120.anIntArrayArrayArray2287[i_33_];
		    i_31_ += arg3;
		    byte[][] is_39_
			= Class67_Sub5_Sub1.aByteArrayArrayArray4458[i_33_];
		    byte[][] is_40_ = Class53.aByteArrayArrayArray1062[i_33_];
		    byte[][] is_41_ = Class87.aByteArrayArrayArray1783[i_33_];
		    byte[][] is_42_ = Class49.aByteArrayArrayArray1005[i_33_];
		    byte[][] is_43_
			= Class67_Sub1_Sub9.aByteArrayArrayArray3956[i_33_];
		    int i_44_ = 0;
		    for (/**/; i > i_44_; i_44_++) {
			int i_45_ = arg1 * i_44_ + arg6 >> 132641680;
			int i_46_ = arg6 + (1 + i_44_) * arg1 >> -1589727376;
			int i_47_ = i_46_ - i_45_;
			if (i_47_ > 0) {
			    int i_48_ = i_44_ - -arg2 >> 473608806;
			    i_45_ += arg7;
			    i_46_ += arg7;
			    int i_49_ = arg2 + i_44_ & 0x3f;
			    int i_50_ = i_29_ - -arg5 & 0x3f;
			    int i_51_ = i_50_ + (i_49_ << 588933510);
			    int i_52_;
			    if (i_48_ < 0 || -1 + is.length < i_48_
				|| is[i_48_] == null) {
				if (Class114.aClass67_Sub5_Sub6_2155.anInt4543
				    != -1)
				    i_52_ = (Class114.aClass67_Sub5_Sub6_2155
					     .anInt4543);
				else if ((arg5 + i_29_ & 0x4)
					 == (arg2 + i_44_ & 0x4))
				    i_52_
					= (Class67_Sub1_Sub16_Sub1
					   .anIntArray5098
					   [1 + Class67_Sub1_Sub37.anInt4402]);
				else
				    i_52_ = 4936552;
				if (i_48_ < 0 || ((is.length - 1 ^ 0xffffffff)
						  > (i_48_ ^ 0xffffffff))) {
				    if (i_52_ == 0)
					i_52_ = 1;
				    Class121.method1683(i_31_, i_45_, i_32_,
							i_47_, i_52_);
				    continue;
				}
			    } else
				i_52_ = is[i_48_][i_51_];
			    if (i_52_ == 0)
				i_52_ = 1;
			    int i_53_
				= (is_40_[i_48_] == null ? 0
				   : (Class67_Sub1_Sub16_Sub1.anIntArray5098
				      [0xff & is_40_[i_48_][i_51_]]));
			    int i_54_
				= (is_39_[i_48_] != null
				   ? (Class67_Sub1_Sub16_Sub1.anIntArray5098
				      [is_39_[i_48_][i_51_] & 0xff])
				   : 0);
			    if ((i_54_ ^ 0xffffffff) == -1 && i_53_ == 0)
				Class121.method1683(i_31_, i_45_, i_32_, i_47_,
						    i_52_);
			    else {
				if (i_54_ != 0) {
				    if ((i_54_ ^ 0xffffffff) == 0)
					i_54_ = 1;
				    int i_55_ = (is_41_[i_48_] != null
						 ? is_41_[i_48_][i_51_] : 0);
				    int i_56_ = i_55_ & 0xfc;
				    if ((i_56_ ^ 0xffffffff) != -1 && i_32_ > 1
					&& (i_47_ ^ 0xffffffff) < -2)
					Class50.method431(i_54_,
							  i_56_ >> 167302146,
							  i_32_, true, i_52_,
							  i_31_, 0x3 & i_55_,
							  (Class121
							   .anIntArray2300),
							  i_47_, 0, i_45_);
				    else
					Class121.method1683(i_31_, i_45_,
							    i_32_, i_47_,
							    i_54_);
				}
				if ((i_53_ ^ 0xffffffff) != -1) {
				    if (i_53_ == -1)
					i_53_ = i_52_;
				    int i_57_ = is_42_[i_48_][i_51_];
				    int i_58_ = 0xfc & i_57_;
				    if ((i_58_ ^ 0xffffffff) == -1
					|| (i_32_ ^ 0xffffffff) >= -2
					|| i_47_ <= 1)
					Class121.method1683(i_31_, i_45_,
							    i_32_, i_47_,
							    i_53_);
				    Class50.method431(i_53_,
						      i_58_ >> 1205101442,
						      i_32_,
						      ((i_54_ ^ 0xffffffff)
						       == -1),
						      0, i_31_, 0x3 & i_57_,
						      Class121.anIntArray2300,
						      i_47_, 0, i_45_);
				}
			    }
			    if (is_43_[i_48_] != null) {
				int i_59_ = 0xff & is_43_[i_48_][i_51_];
				if ((i_59_ ^ 0xffffffff) != -1) {
				    int i_60_;
				    if ((i_32_ ^ 0xffffffff) == -2)
					i_60_ = i_31_;
				    else
					i_60_ = -1 + i_30_;
				    int i_61_ = 13421772;
				    int i_62_;
				    if ((i_47_ ^ 0xffffffff) != -2)
					i_62_ = -1 + i_46_;
				    else
					i_62_ = i_45_;
				    if (((i_59_ ^ 0xffffffff) <= -6
					 && (i_59_ ^ 0xffffffff) >= -9)
					|| i_59_ >= 13 && i_59_ <= 16
					|| ((i_59_ ^ 0xffffffff) <= -22
					    && i_59_ <= 24)
					|| i_59_ == 27
					|| (i_59_ ^ 0xffffffff) == -29) {
					i_61_ = 13369344;
					i_59_ -= 4;
				    }
				    if (i_59_ != 1) {
					if (i_59_ == 2)
					    Class121.method1690(i_31_, i_45_,
								i_32_, i_61_);
					else if ((i_59_ ^ 0xffffffff) == -4)
					    Class121.method1692(i_60_, i_45_,
								i_47_, i_61_);
					else if (i_59_ != 4) {
					    if (i_59_ == 9) {
						Class121.method1692(i_31_,
								    i_45_,
								    i_47_,
								    16777215);
						Class121.method1690(i_31_,
								    i_45_,
								    i_32_,
								    i_61_);
					    } else if ((i_59_ ^ 0xffffffff)
						       != -11) {
						if ((i_59_ ^ 0xffffffff)
						    == -12) {
						    Class121.method1692
							(i_60_, i_45_, i_47_,
							 16777215);
						    Class121.method1690(i_31_,
									i_62_,
									i_32_,
									i_61_);
						} else if (i_59_ != 12) {
						    if ((i_59_ ^ 0xffffffff)
							== -18)
							Class121.method1690
							    (i_31_, i_45_, 1,
							     i_61_);
						    else if (i_59_ != 18) {
							if (i_59_ != 19) {
							    if (i_59_ == 20)
								Class121
								    .method1690
								    (i_31_,
								     i_62_, 1,
								     i_61_);
							    else if (i_59_
								     != 25) {
								if (i_59_
								    == 26) {
								    for (int i_63_
									     = 0;
									 (i_63_
									  < i_47_);
									 i_63_++)
									Class121
									    .method1690
									    (i_63_ + i_31_,
									     i_45_ - -i_63_,
									     1,
									     i_61_);
								}
							    } else {
								for (int i_64_
									 = 0;
								     (i_47_
								      > i_64_);
								     i_64_++)
								    Class121
									.method1690
									((i_64_
									  + i_31_),
									 (i_62_
									  - i_64_),
									 1,
									 i_61_);
							    }
							} else
							    Class121.method1690
								(i_60_, i_62_,
								 1, i_61_);
						    } else
							Class121.method1690
							    (i_60_, i_45_, 1,
							     i_61_);
						} else {
						    Class121.method1692
							(i_31_, i_45_, i_47_,
							 16777215);
						    Class121.method1690(i_31_,
									i_62_,
									i_32_,
									i_61_);
						}
					    } else {
						Class121.method1692(i_60_,
								    i_45_,
								    i_47_,
								    16777215);
						Class121.method1690(i_31_,
								    i_45_,
								    i_32_,
								    i_61_);
					    }
					} else
					    Class121.method1690(i_31_, i_62_,
								i_32_, i_61_);
				    } else
					Class121.method1692(i_31_, i_45_,
							    i_47_, i_61_);
				}
			    }
			}
		    }
		}
	    }
	}
	for (int i_65_ = -2; i_28_ + 2 > i_65_; i_65_++) {
	    int i_66_ = arg9 * i_65_ + arg10 >> 1585154928;
	    int i_67_ = arg9 * (i_65_ - -1) + arg10 >> 973206256;
	    int i_68_ = i_67_ + -i_66_;
	    if ((i_68_ ^ 0xffffffff) < -1) {
		i_67_ += arg3;
		int i_69_ = i_65_ - -arg5 >> 2101495974;
		i_66_ += arg3;
		if (i_69_ >= 0
		    && -1 + Class6.anIntArrayArrayArray148.length >= i_69_) {
		    int[][] is = Class6.anIntArrayArrayArray148[i_69_];
		    for (int i_70_ = -2; i_70_ < i + 2; i_70_++) {
			int i_71_ = arg1 * i_70_ + arg6 >> 1502806352;
			int i_72_ = arg1 * (i_70_ + 1) + arg6 >> -937952016;
			int i_73_ = i_72_ + -i_71_;
			if (i_73_ > 0) {
			    i_71_ += arg7;
			    int i_74_ = arg2 + i_70_ >> -1721912602;
			    i_72_ += arg7;
			    if (i_74_ >= 0 && ((is.length - 1 ^ 0xffffffff)
					       <= (i_74_ ^ 0xffffffff))) {
				int i_75_ = ((0x3f & i_65_ - -arg5)
					     + ((arg2 + i_70_ & 0x3f)
						<< -1732578458));
				if (is[i_74_] != null) {
				    int i_76_ = is[i_74_][i_75_];
				    int i_77_ = i_76_ & 0x3fff;
				    if (i_77_ != 0) {
					Class24 class24
					    = Class32.method284(i_77_ + -1,
								34);
					int i_78_ = 0x3 & i_76_ >> -1260935698;
					Class119_Sub1 class119_sub1
					    = class24.method223(i_78_,
								(byte) -84);
					if (class119_sub1 != null) {
					    int i_79_
						= (class119_sub1.anInt2254
						   * i_73_ / 4);
					    int i_80_
						= (i_68_
						   * class119_sub1.anInt2252
						   / 4);
					    if (class24.aBoolean580) {
						int i_81_
						    = 0xf & i_76_ >> 796098704;
						int i_82_
						    = i_76_ >> 852661748 & 0xf;
						if ((0x1 & i_78_ ^ 0xffffffff)
						    == -2) {
						    i_78_ = i_81_;
						    i_81_ = i_82_;
						    i_82_ = i_78_;
						}
						i_80_ = i_81_ * i_68_;
						i_79_ = i_73_ * i_82_;
					    }
					    if (i_80_ != 0 && i_79_ != 0) {
						if (class24.anInt571 == 0)
						    class119_sub1.method1647
							(i_66_,
							 (i_73_ + i_71_
							  + -i_79_),
							 i_80_, i_79_);
						else
						    class119_sub1.method1648
							(i_66_,
							 -i_79_ + (i_71_
								   - -i_73_),
							 i_80_, i_79_,
							 class24.anInt571);
					    }
					}
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    
    public int method1876(byte arg0) {
	if (arg0 <= 90)
	    return 37;
	anInt3694++;
	if ((anInt3776 ^ 0xffffffff) == 32767)
	    return 200;
	return -anInt3776;
    }
    
    public void method1877(int arg0, int arg1, byte arg2, int arg3,
			   boolean arg4) {
	anInt3744++;
	if ((anInt3735 ^ 0xffffffff) != 0
	    && Class120.method1666(anInt3735, -32).anInt859 == 1)
	    anInt3735 = -1;
	if (!arg4) {
	    int i = arg1 - smallY[0];
	    int i_83_ = arg3 - smallX[0];
	    if ((i_83_ ^ 0xffffffff) <= 7 && i_83_ <= 8
		&& (i ^ 0xffffffff) <= 7 && i <= 8) {
		if ((anInt3713 ^ 0xffffffff) > -10)
		    anInt3713++;
		for (int i_84_ = anInt3713; (i_84_ ^ 0xffffffff) < -1;
		     i_84_--) {
		    smallX[i_84_] = smallX[-1 + i_84_];
		    smallY[i_84_] = smallY[i_84_ - 1];
		    aByteArray3711[i_84_] = aByteArray3711[i_84_ + -1];
		}
		aByteArray3711[0] = (byte) 1;
		smallX[0] = arg3;
		smallY[0] = arg1;
		return;
	    }
	}
	if (arg2 <= 3)
	    method1879((byte) 94);
	anInt3787 = 0;
	anInt3727 = 0;
	anInt3713 = 0;
	smallX[0] = arg3;
	smallY[0] = arg1;
	anInt3726 = smallY[0] * 128 - -(arg0 * 64);
	anInt3733 = arg0 * 64 + 128 * smallX[0];
    }
    
    public boolean method1878(byte arg0) {
	anInt3693++;
	if (arg0 != 62)
	    return false;
	return false;
    }
    
    public static void method1879(byte arg0) {
	anInt3703++;
	Class54.aPacketStream_1069.initBitAccess(arg0 + -210);
	int i = Class54.aPacketStream_1069.readBits((byte) 9, 8);
	if ((Class37.anInt794 ^ 0xffffffff) < (i ^ 0xffffffff)) {
	    for (int i_85_ = i;
		 (i_85_ ^ 0xffffffff) > (Class37.anInt794 ^ 0xffffffff);
		 i_85_++)
		Class67_Sub1_Sub2.anIntArray3830[Class55_Sub3.anInt2807++]
		    = Class47.anIntArray965[i_85_];
	}
	if (i > Class37.anInt794)
	    throw new RuntimeException("gnpov1");
	Class37.anInt794 = 0;
	if (arg0 != 88)
	    method1885(0, -80, 94, 86, 51, null, -35, -73L, false);
	for (int i_86_ = 0; (i_86_ ^ 0xffffffff) > (i ^ 0xffffffff); i_86_++) {
	    int i_87_ = Class47.anIntArray965[i_86_];
	    Class131_Sub7_Sub1 class131_sub7_sub1
		= Class128.aClass131_Sub7_Sub1Array2386[i_87_];
	    int i_88_ = Class54.aPacketStream_1069.readBits((byte) 9, 1);
	    if (i_88_ == 0) {
		Class47.anIntArray965[Class37.anInt794++] = i_87_;
		class131_sub7_sub1.anInt3789 = Class67_Sub1_Sub9.anInt3952;
	    } else {
		int i_89_ = Class54.aPacketStream_1069.readBits((byte) 9, 2);
		if ((i_89_ ^ 0xffffffff) == -1) {
		    Class47.anIntArray965[Class37.anInt794++] = i_87_;
		    class131_sub7_sub1.anInt3789 = Class67_Sub1_Sub9.anInt3952;
		    Class61.anIntArray1142[Class126_Sub2.anInt3439++] = i_87_;
		} else if  ((i_89_ ^ 0xffffffff) == -2) {
		    Class47.anIntArray965[Class37.anInt794++] = i_87_;
		    class131_sub7_sub1.anInt3789 = Class67_Sub1_Sub9.anInt3952;
		    int i_90_ = Class54.aPacketStream_1069.readBits((byte) 9, 3);
		    class131_sub7_sub1.method1886(i_90_, 1, arg0 ^ 0x5b);
		    int i_91_ = Class54.aPacketStream_1069.readBits((byte) 9,
								     1);
		    if (i_91_ == 1)
			Class61.anIntArray1142[Class126_Sub2.anInt3439++]
			    = i_87_;
		} else if (i_89_ == 2) {
		    Class47.anIntArray965[Class37.anInt794++] = i_87_;
		    class131_sub7_sub1.anInt3789 = Class67_Sub1_Sub9.anInt3952;
		    if((Class54.aPacketStream_1069.readBits((byte) 9,
								    1)
			 ^ 0xffffffff)
			!= -2) {
			int i_92_ = Class54.aPacketStream_1069.readBits((byte) 9, 3);
			class131_sub7_sub1.method1886(i_92_, 0, 3);
		    } else {
			int i_93_ = Class54.aPacketStream_1069.readBits((byte) 9, 3);
			class131_sub7_sub1.method1886(i_93_, 2, 3);
			int i_94_ = Class54.aPacketStream_1069.readBits((byte) 9, 3);
			class131_sub7_sub1.method1886(i_94_, 2, 3);
		    }
		    int i_95_ = Class54.aPacketStream_1069.readBits((byte) 9, 1);
		    if ((i_95_ ^ 0xffffffff) == -2)
			Class61.anIntArray1142[Class126_Sub2.anInt3439++] = i_87_;
		} else if ((i_89_ ^ 0xffffffff) == -4)
		    Class67_Sub1_Sub2.anIntArray3830[Class55_Sub3.anInt2807++] = i_87_;
	    }
	}
    }
    
    public Class87 method1880(byte arg0) {
	if (arg0 > -28)
	    return null;
	anInt3730++;
	int i = getPlayerAnims(0);
	if (i != -1)
	    return Class67_Sub5_Sub1.method824(false, i);
	return Class120.aClass87_2279;
    }
    
    public void method1881(int arg0, int arg1, int arg2, int arg3) {
	anInt3755++;
	if (arg2 <= 23)
	    method1887((byte) -107);
	for (int i = 0; i < 4; i++) {
	    if (arg1 >= anIntArray3697[i]) {
		anIntArray3774[i] = arg0;
		anIntArray3763[i] = arg3;
		anIntArray3697[i] = arg1 - -70;
		break;
	    }
	}
    }
    
    public abstract int getPlayerAnims(int i);
    
    public void method1883(int arg0, int arg1) {
	do {
	    try {
		anInt3708 = arg1;
		anInt3702++;
		if (arg0 == 0)
		    break;
		method1874(108, 116, -16);
	    } catch (RuntimeException runtimeexception) {
		throw Class67_Sub1_Sub21.method718(runtimeexception,
						   ("ob.S(" + arg0 + ',' + arg1
						    + ')'));
	    }
	    break;
	} while (false);
    }
    
    public void method1884(byte arg0, Class131_Sub6 arg1) {
	do {
	    try {
		int i = -67 % ((-67 - arg0) / 43);
		Class87 class87 = method1880((byte) -79);
		anInt3724++;
		if ((class87.anInt1780 ^ 0xffffffff) != -1
		    || (class87.anInt1792 ^ 0xffffffff) != -1) {
		    int i_96_ = 0;
		    int i_97_ = 0;
		    if (aBoolean3772 && (anInt3756 ^ 0xffffffff) != -1) {
			if (anInt3756 < 0)
			    i_96_ = -class87.anInt1780;
			else
			    i_96_ = class87.anInt1780;
			i_97_ = class87.anInt1792;
		    }
		    if (anInt3716 != i_96_) {
			anInt3716 = i_96_;
			if ((anInt3731 ^ 0xffffffff) >= -1
			    || i_96_ <= anInt3759) {
			    if ((anInt3731 ^ 0xffffffff) > -1
				&& anInt3759 > i_96_) {
				int i_98_ = -anInt3759 + i_96_;
				int i_99_ = (anInt3731 * anInt3731
					     / (2 * class87.anInt1799));
				if ((i_99_ ^ 0xffffffff)
				    >= (i_98_ ^ 0xffffffff)) {
				    anInt3788
					= (i_99_ + anInt3759 - -i_96_) / 2;
				    aBoolean3751 = true;
				    int i_100_ = (class87.anInt1772
						  * class87.anInt1772
						  / (class87.anInt1799 * 2));
				    int i_101_ = i_96_ - -i_100_;
				    if ((i_101_ ^ 0xffffffff)
					> (anInt3788 ^ 0xffffffff))
					anInt3788 = i_101_;
				} else
				    aBoolean3751 = false;
			    } else
				aBoolean3751 = false;
			} else {
			    int i_102_ = (anInt3731 * anInt3731
					  / (class87.anInt1799 * 2));
			    int i_103_ = -anInt3759 + i_96_;
			    if (i_102_ > i_103_)
				aBoolean3751 = false;
			    else {
				anInt3788 = (i_96_ + -i_102_ + anInt3759) / 2;
				aBoolean3751 = true;
				int i_104_
				    = (class87.anInt1772 * class87.anInt1772
				       / (2 * class87.anInt1799));
				int i_105_ = i_96_ - i_104_;
				if ((i_105_ ^ 0xffffffff)
				    < (anInt3788 ^ 0xffffffff))
				    anInt3788 = i_105_;
			    }
			}
		    }
		    if (anInt3731 != 0) {
			if ((anInt3731 ^ 0xffffffff) >= -1) {
			    if (anInt3759 <= anInt3788)
				aBoolean3751 = false;
			    if (aBoolean3751) {
				if (anInt3731 > -class87.anInt1772)
				    anInt3731 -= class87.anInt1799;
			    } else {
				anInt3731 += class87.anInt1799;
				if ((anInt3731 ^ 0xffffffff) < -1)
				    anInt3731 = 0;
			    }
			} else {
			    if ((anInt3759 ^ 0xffffffff)
				<= (anInt3788 ^ 0xffffffff))
				aBoolean3751 = false;
			    if (aBoolean3751) {
				if (class87.anInt1772 > anInt3731)
				    anInt3731 += class87.anInt1799;
			    } else {
				anInt3731 -= class87.anInt1799;
				if ((anInt3731 ^ 0xffffffff) > -1)
				    anInt3731 = 0;
			    }
			}
		    } else {
			int i_106_ = anInt3716 + -anInt3759;
			if (i_106_ > -class87.anInt1799
			    && ((class87.anInt1799 ^ 0xffffffff)
				< (i_106_ ^ 0xffffffff)))
			    anInt3759 = anInt3716;
			else {
			    aBoolean3751 = true;
			    anInt3788 = (anInt3759 + anInt3716) / 2;
			    int i_107_ = (class87.anInt1772 * class87.anInt1772
					  / (2 * class87.anInt1799));
			    if (i_106_ < 0) {
				anInt3731 = -class87.anInt1799;
				int i_108_ = anInt3716 + i_107_;
				if (anInt3788 > i_108_)
				    anInt3788 = i_108_;
			    } else {
				anInt3731 = class87.anInt1799;
				int i_109_ = -i_107_ + anInt3716;
				if ((anInt3788 ^ 0xffffffff)
				    > (i_109_ ^ 0xffffffff))
				    anInt3788 = i_109_;
			    }
			}
		    }
		    anInt3759 += anInt3731;
		    if ((anInt3759 ^ 0xffffffff) != -1) {
			int i_110_ = (0xffec & anInt3759) >> 1526455365;
			int i_111_ = arg1.method1769() / 2;
			arg1.method1837(0, -i_111_, 0);
			arg1.method1836(i_110_);
			arg1.method1837(0, i_111_, 0);
		    }
		    if ((i_97_ ^ 0xffffffff) != (anInt3764 ^ 0xffffffff)) {
			anInt3764 = i_97_;
			if ((anInt3775 ^ 0xffffffff) < -1
			    && (i_97_ ^ 0xffffffff) < (anInt3700
						       ^ 0xffffffff)) {
			    int i_112_ = (anInt3775 * anInt3775
					  / (class87.anInt1809 * 2));
			    int i_113_ = -anInt3700 + i_97_;
			    if (i_112_ <= i_113_) {
				aBoolean3779 = true;
				anInt3737
				    = (i_97_ + (anInt3700 + -i_112_)) / 2;
				int i_114_
				    = (class87.anInt1787 * class87.anInt1787
				       / (2 * class87.anInt1809));
				int i_115_ = i_97_ - i_114_;
				if ((i_115_ ^ 0xffffffff)
				    < (anInt3737 ^ 0xffffffff))
				    anInt3737 = i_115_;
			    } else
				aBoolean3779 = false;
			} else if ((anInt3775 ^ 0xffffffff) > -1
				   && ((anInt3700 ^ 0xffffffff)
				       < (i_97_ ^ 0xffffffff))) {
			    int i_116_ = (anInt3775 * anInt3775
					  / (class87.anInt1809 * 2));
			    int i_117_ = i_97_ - anInt3700;
			    if (i_116_ <= i_117_) {
				int i_118_
				    = (class87.anInt1787 * class87.anInt1787
				       / (2 * class87.anInt1809));
				aBoolean3779 = true;
				anInt3737
				    = (i_97_ + (anInt3700 - -i_116_)) / 2;
				int i_119_ = i_97_ + i_118_;
				if ((anInt3737 ^ 0xffffffff)
				    < (i_119_ ^ 0xffffffff))
				    anInt3737 = i_119_;
			    } else
				aBoolean3779 = false;
			} else
			    aBoolean3779 = false;
		    }
		    if ((anInt3775 ^ 0xffffffff) == -1) {
			int i_120_ = -anInt3700 + anInt3764;
			if ((i_120_ ^ 0xffffffff) >= (-class87.anInt1809
						      ^ 0xffffffff)
			    || i_120_ >= class87.anInt1809) {
			    aBoolean3779 = true;
			    anInt3737 = (anInt3700 - -anInt3764) / 2;
			    int i_121_ = (class87.anInt1787 * class87.anInt1787
					  / (2 * class87.anInt1809));
			    if ((i_120_ ^ 0xffffffff) <= -1) {
				anInt3775 = class87.anInt1809;
				int i_122_ = anInt3764 - i_121_;
				if (anInt3737 < i_122_)
				    anInt3737 = i_122_;
			    } else {
				anInt3775 = -class87.anInt1809;
				int i_123_ = i_121_ + anInt3764;
				if ((i_123_ ^ 0xffffffff)
				    > (anInt3737 ^ 0xffffffff))
				    anInt3737 = i_123_;
			    }
			} else
			    anInt3700 = anInt3764;
		    } else if ((anInt3775 ^ 0xffffffff) < -1) {
			if ((anInt3737 ^ 0xffffffff)
			    >= (anInt3700 ^ 0xffffffff))
			    aBoolean3779 = false;
			if (!aBoolean3779) {
			    anInt3775 -= class87.anInt1809;
			    if (anInt3775 < 0)
				anInt3775 = 0;
			} else if (anInt3775 < class87.anInt1787)
			    anInt3775 += class87.anInt1809;
		    } else {
			if ((anInt3737 ^ 0xffffffff)
			    <= (anInt3700 ^ 0xffffffff))
			    aBoolean3779 = false;
			if (!aBoolean3779) {
			    anInt3775 += class87.anInt1809;
			    if (anInt3775 > 0)
				anInt3775 = 0;
			} else if (anInt3775 > -class87.anInt1787)
			    anInt3775 -= class87.anInt1809;
		    }
		    anInt3700 += anInt3775;
		    if (anInt3700 == 0)
			break;
		    int i_124_ = 0x7ff & anInt3700 >> 137499973;
		    int i_125_ = arg1.method1769() / 2;
		    arg1.method1837(0, -i_125_, 0);
		    arg1.method1847(i_124_);
		    arg1.method1837(0, i_125_, 0);
		}
	    } catch (RuntimeException runtimeexception) {
		throw Class67_Sub1_Sub21.method718(runtimeexception,
						   ("ob.M(" + arg0 + ','
						    + (arg1 != null ? "{...}"
						       : "null")
						    + ')'));
	    }
	    break;
	} while (false);
    }
    
    public static boolean method1885(int arg0, int arg1, int arg2, int arg3,
				     int arg4, Class131 arg5, int arg6,
				     long arg7, boolean arg8) {
	if (arg5 == null)
	    return true;
	int i = arg1 - arg4;
	int i_126_ = arg2 - arg4;
	int i_127_ = arg1 + arg4;
	int i_128_ = arg2 + arg4;
	if (arg8) {
	    if (arg6 > 640 && arg6 < 1408)
		i_128_ += 128;
	    if (arg6 > 1152 && arg6 < 1920)
		i_127_ += 128;
	    if (arg6 > 1664 || arg6 < 384)
		i_126_ -= 128;
	    if (arg6 > 128 && arg6 < 896)
		i -= 128;
	}
	i /= 128;
	i_126_ /= 128;
	i_127_ /= 128;
	i_128_ /= 128;
	return Class12.method151(arg0, i, i_126_, i_127_ - i + 1,
				 i_128_ - i_126_ + 1, arg1, arg2, arg3, arg5,
				 arg6, true, arg7);
    }
    
    public void method1886(int arg0, int arg1, int arg2) {
	try {
	    anInt3752++;
	    int i = smallY[0];
	    int i_129_ = smallX[0];
	    if ((arg0 ^ 0xffffffff) == -1) {
		i++;
		i_129_--;
	    }
	    if (arg0 == 1)
		i++;
	    if ((arg0 ^ 0xffffffff) == -3) {
		i_129_++;
		i++;
	    }
	    if (arg2 == arg0)
		i_129_--;
	    if (arg0 == 4)
		i_129_++;
	    if ((arg0 ^ 0xffffffff) == -6) {
		i--;
		i_129_--;
	    }
	    if (arg0 == 6)
		i--;
	    if (arg0 == 7) {
		i_129_++;
		i--;
	    }
	    if ((anInt3735 ^ 0xffffffff) != 0
		&& ((Class120.method1666(anInt3735, -32).anInt859 ^ 0xffffffff)
		    == -2))
		anInt3735 = -1;
	    if (anInt3713 < 9)
		anInt3713++;
	    for (int i_130_ = anInt3713; i_130_ > 0; i_130_--) {
		smallX[i_130_] = smallX[-1 + i_130_];
		smallY[i_130_] = smallY[-1 + i_130_];
		aByteArray3711[i_130_] = aByteArray3711[i_130_ - 1];
	    }
	    smallX[0] = i_129_;
	    smallY[0] = i;
	    aByteArray3711[0] = (byte) arg1;
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       ("ob.N(" + arg0 + ',' + arg1
						+ ',' + arg2 + ')'));
	}
    }
    
    public int method1887(byte arg0) {
	try {
	    anInt3748++;
	    if (arg0 > -8)
		return -40;
	    return anInt3708;
	} catch (RuntimeException runtimeexception) {
	    throw Class67_Sub1_Sub21.method718(runtimeexception,
					       "ob.T(" + arg0 + ')');
	}
    }
    
    public Class131_Sub7() {
	aByteArray3711 = new byte[10];
	aBoolean3699 = false;
	anInt3731 = 0;
	anInt3713 = 0;
	anInt3739 = -1;
	anInt3742 = 0;
	anInt3708 = 1;
	anInt3700 = 0;
	aBoolean3751 = false;
	anInt3741 = 0;
	anInt3704 = -1;
	aClass21Array3749 = new Class21[12];
	anInt3707 = 0;
	anInt3706 = 0;
	anInt3756 = 0;
	anIntArray3763 = new int[4];
	anInt3717 = 0;
	anIntArray3697 = new int[4];
	anInt3745 = 0;
	anInt3746 = 0;
	anInt3775 = 0;
	aBoolean3772 = false;
	anInt3691 = 32;
	anInt3776 = -32768;
	anInt3773 = 100;
	anInt3754 = 0;
	anInt3750 = 0;
	anInt3727 = 0;
	anInt3769 = 0;
	anInt3738 = 0;
	anInt3735 = -1;
	aRSString_3723 = null;
	anInt3757 = 0;
	anInt3777 = 0;
	anInt3737 = 0;
	anInt3764 = 0;
	anInt3722 = -1;
	anInt3712 = 0;
	aBoolean3779 = false;
	anInt3778 = 0;
	anInt3716 = 0;
	anInt3758 = 0;
	anIntArray3774 = new int[4];
	anInt3785 = -1;
	anInt3788 = 0;
	anInt3720 = -1;
	anInt3784 = 0;
	smallX = new int[10];
	anInt3789 = 0;
	anInt3783 = 0;
	anInt3787 = 0;
	smallY = new int[10];
	anInt3759 = 0;
	anInt3780 = -1;
	anInt3791 = 0;
	anInt3792 = 0;
    }
    
    static {
	anIntArray3767 = new int[14];
    }
}
