/* Class46 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class46
{
    public int[] anIntArray948;
    public int anInt949;
    public int[] anIntArray950;
    public int anInt951;
    
    public Class46() {
	Class67_Sub18.method1259(16);
	anInt951 = (Class67_Sub18.method1252() != 0
		    ? Class67_Sub18.method1259(4) + 1 : 1);
	if (Class67_Sub18.method1252() != 0)
	    Class67_Sub18.method1259(8);
	Class67_Sub18.method1259(2);
	if (anInt951 > 1)
	    anInt949 = Class67_Sub18.method1259(4);
	anIntArray948 = new int[anInt951];
	anIntArray950 = new int[anInt951];
	for (int i = 0; i < anInt951; i++) {
	    Class67_Sub18.method1259(8);
	    anIntArray948[i] = Class67_Sub18.method1259(8);
	    anIntArray950[i] = Class67_Sub18.method1259(8);
	}
    }
}
