public class Class118
{
    public static RSString aRSString_2230;
    public static int anInt2231;
    public static int anInt2232;
    public static RSString aRSString_2233
	= Class134.method1914("Chargement en cours)3)3)3", (byte) 85);
    public static RSString aRSString_2234
	= Class134.method1914("Ausw-=hlen", (byte) 52);
    public static int[] anIntArray2235;
    public static RSString aRSString_2236
	= Class134.method1914("clignotant1:", (byte) 125);
    public static int anInt2237;
    public static int anInt2238;
    public static int anInt2239;
    public static int anInt2240;
    
    public static int method1636(int arg0) {
	anInt2240++;
	if (arg0 != -2)
	    aRSString_2233 = null;
	if (!Class131_Sub7_Sub2.aBoolean5068
	    || !Class131_Sub7.aBooleanArray3698[81]
	    || (Class134.anInt2476 ^ 0xffffffff) >= -3)
	    return Class55_Sub2.anIntArray2802[Class134.anInt2476 + -1];
	return Class55_Sub2.anIntArray2802[Class134.anInt2476 + -2];
    }
    
    public static void method1637(byte arg0) {
	if (arg0 == -24) {
	    anInt2237++;
	    for (;;) {
		Class67_Sub12 class67_sub12
		    = ((Class67_Sub12)
		       Class67_Sub1_Sub19.aClass50_4128.method442(true));
		if (class67_sub12 == null)
		    break;
		Class131_Sub7 class131_sub7;
		if (class67_sub12.anInt3037 >= 0) {
		    int i = class67_sub12.anInt3037 + -1;
		    class131_sub7 = Class128.aClass131_Sub7_Sub1Array2386[i];
		} else {
		    int i = -1 + -class67_sub12.anInt3037;
		    if ((i ^ 0xffffffff)
			== (Class67_Sub17.anInt3102 ^ 0xffffffff))
			class131_sub7 = Class122.aClass131_Sub7_Sub2_2309;
		    else
			class131_sub7 = (Class67_Sub5_Sub18
					 .aClass131_Sub7_Sub2Array4810[i]);
		}
		if (class131_sub7 != null) {
		    Class65 class65
			= Class73.method1359(arg0 + 11549,
					     class67_sub12.anInt3028);
		    int i;
		    int i_0_;
		    if ((class67_sub12.anInt3039 ^ 0xffffffff) == -2
			|| class67_sub12.anInt3039 == 3) {
			i_0_ = class65.anInt1264;
			i = class65.anInt1297;
		    } else {
			i = class65.anInt1264;
			i_0_ = class65.anInt1297;
		    }
		    int i_1_ = (i_0_ >> 515585153) + class67_sub12.anInt3031;
		    int i_2_ = class67_sub12.anInt3035 - -(i >> 1671354945);
		    int i_3_
			= class67_sub12.anInt3031 + (1 + i_0_ >> -1970265087);
		    int[][] is = (Class136.anIntArrayArrayArray2496
				  [Canvas_Sub1.anInt59]);
		    int i_4_
			= (i - -1 >> 1560117857) + class67_sub12.anInt3035;
		    Class131 class131 = null;
		    int i_5_
			= Class123.anIntArray2316[class67_sub12.anInt3034];
		    int i_6_
			= (is[i_3_][i_4_] + is[i_3_][i_2_] + (is[i_1_][i_2_]
							      + is[i_1_][i_4_])
			   >> 521692738);
		    if ((i_5_ ^ 0xffffffff) != -1) {
			if ((i_5_ ^ 0xffffffff) == -2) {
			    Class94 class94 = (Class67_Sub1_Sub16.method684
					       (Canvas_Sub1.anInt59,
						class67_sub12.anInt3031,
						class67_sub12.anInt3035));
			    if (class94 != null)
				class131 = class94.aClass131_1894;
			} else if (i_5_ != 2) {
			    if ((i_5_ ^ 0xffffffff) == -4) {
				Class104 class104
				    = (Class67_Sub5_Sub13.method964
				       (Canvas_Sub1.anInt59,
					class67_sub12.anInt3031,
					class67_sub12.anInt3035));
				if (class104 != null)
				    class131 = class104.aClass131_2034;
			    }
			} else {
			    Class36 class36 = (Class67_Sub1_Sub23.method729
					       (Canvas_Sub1.anInt59,
						class67_sub12.anInt3031,
						class67_sub12.anInt3035));
			    if (class36 != null)
				class131 = class36.aClass131_790;
			}
		    } else {
			Class58 class58
			    = Class67_Sub19.method1263(Canvas_Sub1.anInt59,
						       class67_sub12.anInt3031,
						       (class67_sub12
							.anInt3035));
			if (class58 != null)
			    class131 = class58.aClass131_1121;
		    }
		    if (class131 != null) {
			Class67_Sub5_Sub2.method833
			    (class67_sub12.anInt3040 + 1, false, 0,
			     class67_sub12.anInt3031,
			     class67_sub12.anInt3029 - -1,
			     class67_sub12.anInt3035, Canvas_Sub1.anInt59,
			     i_5_, -1, 0);
			class131_sub7.anObject3747 = class131;
			class131_sub7.anInt3742 = (Class67_Sub1_Sub9.anInt3952
						   + class67_sub12.anInt3029);
			class131_sub7.anInt3762 = i_6_;
			class131_sub7.anInt3782
			    = class67_sub12.anInt3031 * 128 - -(i_0_ * 64);
			int i_7_ = class67_sub12.anInt3026;
			class131_sub7.anInt3706 = (Class67_Sub1_Sub9.anInt3952
						   + class67_sub12.anInt3040);
			int i_8_ = class67_sub12.anInt3038;
			class131_sub7.anInt3692
			    = 64 * i + class67_sub12.anInt3035 * 128;
			int i_9_ = class67_sub12.anInt3033;
			if (i_7_ < i_8_) {
			    int i_10_ = i_8_;
			    i_8_ = i_7_;
			    i_7_ = i_10_;
			}
			int i_11_ = class67_sub12.anInt3030;
			if (i_9_ > i_11_) {
			    int i_12_ = i_9_;
			    i_9_ = i_11_;
			    i_11_ = i_12_;
			}
			class131_sub7.anInt3753
			    = i_11_ + class67_sub12.anInt3035;
			class131_sub7.anInt3771
			    = i_8_ + class67_sub12.anInt3031;
			class131_sub7.anInt3743
			    = i_9_ + class67_sub12.anInt3035;
			class131_sub7.anInt3793
			    = class67_sub12.anInt3031 - -i_7_;
		    }
		}
	    }
	}
    }
    
    public static void method1638(int arg0, Class131_Sub7_Sub1 arg1) {
	int i = -34 % ((arg0 - -68) / 52);
	anInt2239++;
	for (Class67_Sub10 class67_sub10
		 = (Class67_Sub10) Class67_Sub10.aClass50_2987.method445(0);
	     class67_sub10 != null;
	     class67_sub10
		 = (Class67_Sub10) Class67_Sub10.aClass50_2987.method432(0)) {
	    if (class67_sub10.aClass131_Sub7_Sub1_3003 == arg1) {
		if (class67_sub10.aClass67_Sub11_Sub3_2994 != null) {
		    Class67_Sub1_Sub20.aClass67_Sub11_Sub1_4145
			.method1133(class67_sub10.aClass67_Sub11_Sub3_2994);
		    class67_sub10.aClass67_Sub11_Sub3_2994 = null;
		}
		class67_sub10.method606((byte) -118);
		break;
	    }
	}
    }
    
    public static void method1639(int arg0) {
	if (arg0 != 1560117857)
	    aRSString_2230 = null;
	aRSString_2236 = null;
	aRSString_2233 = null;
	aRSString_2230 = null;
	anIntArray2235 = null;
	aRSString_2234 = null;
    }
    
    static {
	aRSString_2230
	    = Class134.method1914("Fichiers config charg-Bs", (byte) 111);
	anIntArray2235
	    = new int[] { 768, 1024, 1280, 512, 1536, 256, 0, 1792 };
	anInt2232 = -1;
    }
}
