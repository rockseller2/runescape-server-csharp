/* Class80 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class80
{
    public static int anInt1622;
    public static int anInt1623;
    public static Class67_Sub3 aClass67_Sub3_1624;
    public static int anInt1625;
    public static short[] aShortArray1626 = { -10304, 9104, -1, -1, -1 };
    public static int anInt1627;
    public static int anInt1628;
    
    public static int method1423(int arg0, RSString arg1) {
	if (arg0 != 18241)
	    anInt1627 = -110;
	anInt1623++;
	return 1 + arg1.method531((byte) -12);
    }
    
    public static void method1424(byte arg0) {
	aClass67_Sub3_1624 = null;
	if (arg0 == -81)
	    aShortArray1626 = null;
    }
    
    public abstract Class67_Sub5_Sub11 method1425
	(byte i, Class67_Sub5_Sub11 class67_sub5_sub11);
    
    static {
	anInt1622 = 0;
	aClass67_Sub3_1624 = new Class67_Sub3(0, 0);
    }
}
