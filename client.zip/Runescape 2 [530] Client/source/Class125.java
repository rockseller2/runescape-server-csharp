public class Class125
{
    public static boolean aBoolean2336 = false;
    public static RSString aRSString_2337;
    public static int anInt2338;
    public static int anInt2339 = 0;
    public static int[] anIntArray2340;
    public static int anInt2341;
    public static volatile long aLong2342;
    public static RSString aRSString_2343;
    
    public static void method1705(Class9 arg0, byte arg1) {
	anInt2341++;
	Class10.aClass9_402 = arg0;
	Class126_Sub1.anInt3413 = Class10.aClass9_402.method135(16, -123);
	if (arg1 != -20)
	    method1707((byte) 17, 67, -94, -48, -68);
    }
    
    public static void method1706(int arg0) {
	anIntArray2340 = null;
	if (arg0 == -8677) {
	    aRSString_2343 = null;
	    aRSString_2337 = null;
	}
    }
    
    public static void method1707(byte arg0, int arg1, int arg2, int arg3,
				  int arg4) {
	anInt2338++;
	for (Class67_Sub10 class67_sub10
		 = (Class67_Sub10) Class92.aClass50_1868.method445(0);
	     class67_sub10 != null;
	     class67_sub10
		 = (Class67_Sub10) Class92.aClass50_1868.method432(0))
	    Class22.method209(class67_sub10, arg3, arg2, arg4, 0, arg1);
	for (Class67_Sub10 class67_sub10
		 = (Class67_Sub10) Class67_Sub10.aClass50_2987.method445(0);
	     class67_sub10 != null;
	     class67_sub10
		 = (Class67_Sub10) Class67_Sub10.aClass50_2987.method432(0)) {
	    int i = 1;
	    Class87 class87 = class67_sub10.aClass131_Sub7_Sub1_3003
				  .method1880((byte) -128);
	    if ((class87.anInt1797 ^ 0xffffffff)
		!= (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
		    ^ 0xffffffff)) {
		if (((class87.anInt1812 ^ 0xffffffff)
		     != (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			 ^ 0xffffffff))
		    && (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			^ 0xffffffff) != (class87.anInt1795 ^ 0xffffffff)
		    && ((class87.anInt1782 ^ 0xffffffff)
			!= (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			    ^ 0xffffffff))
		    && (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			!= class87.anInt1806)) {
		    if (((class87.anInt1790 ^ 0xffffffff)
			 == (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			     ^ 0xffffffff))
			|| (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			    ^ 0xffffffff) == (class87.anInt1793 ^ 0xffffffff)
			|| (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			    ^ 0xffffffff) == (class87.anInt1789 ^ 0xffffffff)
			|| (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3720
			    == class87.anInt1769))
			i = 3;
		} else
		    i = 2;
	    } else
		i = 0;
	    if ((class67_sub10.anInt3005 ^ 0xffffffff) != (i ^ 0xffffffff)) {
		int i_0_
		    = (Class67_Sub1_Sub27.method745
		       ((byte) 112, class67_sub10.aClass131_Sub7_Sub1_3003));
		if (class67_sub10.anInt3008 != i_0_) {
		    if (class67_sub10.aClass67_Sub11_Sub3_2994 != null) {
			Class67_Sub1_Sub20.aClass67_Sub11_Sub1_4145.method1133
			    (class67_sub10.aClass67_Sub11_Sub3_2994);
			class67_sub10.aClass67_Sub11_Sub3_2994 = null;
		    }
		    class67_sub10.anInt3008 = i_0_;
		}
		class67_sub10.anInt3005 = i;
	    }
	    class67_sub10.anInt2997
		= class67_sub10.aClass131_Sub7_Sub1_3003.anInt3733;
	    class67_sub10.anInt2996
		= (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3733
		   + class67_sub10.aClass131_Sub7_Sub1_3003
			 .method1887((byte) -79) * 64);
	    class67_sub10.anInt3007
		= class67_sub10.aClass131_Sub7_Sub1_3003.anInt3726;
	    class67_sub10.anInt2999
		= (class67_sub10.aClass131_Sub7_Sub1_3003.anInt3726
		   + 64 * class67_sub10.aClass131_Sub7_Sub1_3003
			      .method1887((byte) -111));
	    Class22.method209(class67_sub10, arg3, arg2, arg4, 0, arg1);
	}
	if (arg0 != 101)
	    anInt2339 = -89;
	for (Class67_Sub10 class67_sub10
		 = ((Class67_Sub10)
		    Class67_Sub12.aClass92_3036.method1483((byte) 36));
	     class67_sub10 != null;
	     class67_sub10 = (Class67_Sub10) Class67_Sub12.aClass92_3036
						 .method1480(arg0 ^ 0x6e)) {
	    int i = 1;
	    Class87 class87 = class67_sub10.aClass131_Sub7_Sub2_3013
				  .method1880((byte) -34);
	    if ((class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720 ^ 0xffffffff)
		!= (class87.anInt1797 ^ 0xffffffff)) {
		if ((class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
		     == class87.anInt1812)
		    || (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			^ 0xffffffff) == (class87.anInt1795 ^ 0xffffffff)
		    || (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			^ 0xffffffff) == (class87.anInt1782 ^ 0xffffffff)
		    || ((class87.anInt1806 ^ 0xffffffff)
			== (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			    ^ 0xffffffff)))
		    i = 2;
		else if ((class87.anInt1790
			  == class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720)
			 || (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			     == class87.anInt1793)
			 || (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			     ^ 0xffffffff) == (class87.anInt1789 ^ 0xffffffff)
			 || (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3720
			     == class87.anInt1769))
		    i = 3;
	    } else
		i = 0;
	    if (i != class67_sub10.anInt3005) {
		int i_1_ = Class24.method220(91, (class67_sub10
						  .aClass131_Sub7_Sub2_3013));
		if (i_1_ != class67_sub10.anInt3008) {
		    if (class67_sub10.aClass67_Sub11_Sub3_2994 != null) {
			Class67_Sub1_Sub20.aClass67_Sub11_Sub1_4145.method1133
			    (class67_sub10.aClass67_Sub11_Sub3_2994);
			class67_sub10.aClass67_Sub11_Sub3_2994 = null;
		    }
		    class67_sub10.anInt3008 = i_1_;
		}
		class67_sub10.anInt3005 = i;
	    }
	    class67_sub10.anInt2997
		= class67_sub10.aClass131_Sub7_Sub2_3013.anInt3733;
	    class67_sub10.anInt2996
		= (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3733
		   + 64 * class67_sub10.aClass131_Sub7_Sub2_3013
			      .method1887((byte) -48));
	    class67_sub10.anInt3007
		= class67_sub10.aClass131_Sub7_Sub2_3013.anInt3726;
	    class67_sub10.anInt2999
		= (class67_sub10.aClass131_Sub7_Sub2_3013.anInt3726
		   + class67_sub10.aClass131_Sub7_Sub2_3013
			 .method1887((byte) -126) * 64);
	    Class22.method209(class67_sub10, arg3, arg2, arg4, 0, arg1);
	}
    }
    
    static {
	aRSString_2337 = Class134.method1914("blinken2:", (byte) 116);
	aLong2342 = 0L;
	aRSString_2343 = null;
    }
}
