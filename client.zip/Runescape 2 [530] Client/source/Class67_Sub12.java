/* Class67_Sub12 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub12 extends Class67
{
    public int anInt3026;
    public static int[] anIntArray3027 = new int[14];
    public int anInt3028;
    public int anInt3029;
    public int anInt3030;
    public int anInt3031;
    public static int anInt3032;
    public int anInt3033;
    public int anInt3034;
    public int anInt3035;
    public static Class92 aClass92_3036 = new Class92(16);
    public int anInt3037;
    public int anInt3038;
    public int anInt3039;
    public int anInt3040;
    public static int anInt3041;
    public static int anInt3042;
    public static long aLong3043;
    public static RSString aRSString_3044
	= Class134.method1914(" s(West connect-B)3", (byte) 60);
    
    public static void method1220(boolean arg0) {
	anIntArray3027 = null;
	aClass92_3036 = null;
	if (arg0 == false)
	    aRSString_3044 = null;
    }
    
    public static void method1221(byte arg0) {
	Class15.aClass136_451.method1922(0);
	if (arg0 == -33) {
	    Class67_Sub1_Sub7.aClass136_3901.method1922(0);
	    Class19.aClass136_488.method1922(0);
	    anInt3032++;
	}
    }
    
    static {
	aLong3043 = 0L;
    }
}
