/* Class52 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class52
{
    public static int anInt1045;
    public static Class9 aClass9_1046;
    public static long aLong1047;
    public static volatile int anInt1048;
    public static int anInt1049;
    public static RSString aRSString_1050
	= Class134.method1914("null", (byte) 39);
    public static int anInt1051;
    public int anInt1052;
    public static int anInt1053;
    public int anInt1054;
    public static int anInt1055;
    public int anInt1056;
    
    public static void method449(byte arg0, int arg1) {
	anInt1055++;
	if (arg0 <= -127) {
	    Class67_Sub5_Sub3 class67_sub5_sub3
		= Class103.method1558(arg1, false, 6);
	    class67_sub5_sub3.method844(0);
	}
    }
    
    public static void method450(boolean arg0) {
	aClass9_1046 = null;
	aRSString_1050 = null;
	if (arg0 != false)
	    method453(31, 25);
    }
    
    public static int method451(byte arg0) {
	anInt1051++;
	if (arg0 > -12)
	    return -46;
	return 6;
    }
    
    public static Class67_Sub5_Sub19_Sub1[] method452(boolean arg0, int arg1,
						      Class9 arg2, int arg3) {
	anInt1053++;
	if (arg0 != true)
	    method451((byte) 45);
	if (!Class64.method575((byte) 79, arg3, arg1, arg2))
	    return null;
	return Class37.method320(17100);
    }
    
    public static int method453(int arg0, int arg1) {
	if (arg1 > -126)
	    aRSString_1050 = null;
	anInt1049++;
	return arg0 >>> -1503716888;
    }
    
    static {
	anInt1048 = -1;
    }
}
