public class Class130
{
    public int anInt2403;
    public static Class67_Sub5_Sub10 aClass67_Sub5_Sub10_2404;
    public int anInt2405;
    public int anInt2406;
    public int anInt2407;
    public static RSString aRSString_2408
	= Class134.method1914("www)2wtqa", (byte) 61);
    public static Class67_Sub5_Sub19_Sub1 aClass67_Sub5_Sub19_Sub1_2409;
    public byte[] aByteArray2410;
    public int anInt2411;
    public static int anInt2412;
    public int anInt2413;
    public static int anInt2414;
    public static int[] anIntArray2415 = new int[64];
    public static RSString aRSString_2416
	= Class134.method1914("Weiter", (byte) 11);
    public int anInt2417;
    public static int anInt2418;
    public static RSString aRSString_2419;
    public static RSString aRSString_2420
	= Class134.method1914(" is already on your ignore list)3", (byte) 61);
    public static Class9 aClass9_2421;
    public static int anInt2422;
    public byte[] aByteArray2423;
    public static Class68[] aClass68Array2424;
    
    public static void method1758(Stream arg0, int arg1) {
	anInt2412++;
	int i = 0;
	int i_0_ = -51 % ((9 - arg1) / 62);
	for (/**/; i < Class67_Sub6.anInt2873; i++) {
	    int i_1_ = arg0.method1070(-122);
	    int i_2_ = arg0.readUShort(-2386);
	    if ((i_2_ ^ 0xffffffff) == -65536)
		i_2_ = -1;
	    if (Class96.aClass70_Sub1Array1920[i_1_] != null)
		Class96.aClass70_Sub1Array1920[i_1_].anInt1407 = i_2_;
	}
    }
    
    public static int method1759(boolean arg0) {
	anInt2414++;
	if (arg0 != false)
	    method1761(null, -53);
	return Class67_Sub1_Sub37.aClass136_4388.method1923((byte) -14);
    }
    
    public static void method1760(int arg0) {
	aRSString_2420 = null;
	aClass67_Sub5_Sub19_Sub1_2409 = null;
	aRSString_2416 = null;
	aClass9_2421 = null;
	aClass68Array2424 = null;
	aRSString_2408 = null;
	aClass67_Sub5_Sub10_2404 = null;
	anIntArray2415 = null;
	if (arg0 == 0)
	    aRSString_2419 = null;
    }
    
    public static void method1761(Class9 arg0, int arg1) {
	anInt2422++;
	Class134.aClass67_Sub5_Sub19_Sub1Array2465
	    = Class52.method452(true, Class67_Sub12.anInt3041, arg0, 0);
	Class67_Sub5_Sub12.aClass67_Sub5_Sub19Array4681
	    = Class67_Sub1_Sub17.method699(Class67_Sub11_Sub2.anInt4849, arg0,
					   arg1 + 9106, 0);
	Class126_Sub1.aClass67_Sub5_Sub19Array3422
	    = Class67_Sub1_Sub17.method699(Class15.anInt460, arg0, 2048, 0);
	Class95.aClass67_Sub5_Sub19Array1902
	    = Class67_Sub1_Sub17.method699(Class30.anInt703, arg0, 2048, 0);
	Class102.aClass67_Sub5_Sub19Array2006
	    = Class67_Sub1_Sub17.method699(Class137.anInt2519, arg0, 2048, 0);
	Class139.aClass67_Sub5_Sub19Array2524
	    = Class67_Sub1_Sub17.method699(Class62.anInt1162, arg0, 2048, 0);
	Class19.aClass67_Sub5_Sub19Array487
	    = Class67_Sub1_Sub17.method699(Class67_Sub14.anInt3064, arg0, 2048,
					   0);
	Class67_Sub1_Sub4.aClass67_Sub5_Sub19_3862
	    = Class131_Sub5.method1823(arg0, -13886,
				       Class67_Sub1_Sub24.anInt4213, 0);
	Class30.aClass67_Sub5_Sub19Array704
	    = Class99.method1519(0, arg0, (byte) 75, Class40.anInt819);
	Class83.aClass67_Sub5_Sub19Array1687
	    = Class99.method1519(0, arg0, (byte) 70, Class126_Sub1.anInt3419);
	Class85.aClass119Array1742
	    = Class67_Sub1_Sub38.method804(Class105.anInt2052, 0,
					   arg1 + -1006404866, arg0);
	Class5.aClass119Array143
	    = Class67_Sub1_Sub38.method804(Class67_Sub10.anInt3017, 0,
					   arg1 + -1006404866, arg0);
	Class84.aClass67_Sub5_Sub10_1692.method902(Class5.aClass119Array143,
						   null);
	Class143.aClass67_Sub5_Sub10_2583.method902(Class5.aClass119Array143,
						    null);
	aClass67_Sub5_Sub10_2404.method902(Class5.aClass119Array143, null);
	Class67_Sub5_Sub19_Sub1 class67_sub5_sub19_sub1
	    = Class44.method387(-123, arg0, Class67_Sub17.anInt3106, 0);
	class67_sub5_sub19_sub1.method1013();
	Class67_Sub6.aClass67_Sub5_Sub19_2872 = class67_sub5_sub19_sub1;
	Class67_Sub5_Sub19_Sub1[] class67_sub5_sub19_sub1s
	    = Class52.method452(true, Class124.anInt2334, arg0, 0);
	for (int i = 0; i < class67_sub5_sub19_sub1s.length; i++)
	    class67_sub5_sub19_sub1s[i].method1013();
	Class67_Sub1_Sub7.aClass67_Sub5_Sub19Array3911
	    = class67_sub5_sub19_sub1s;
	int i = (int) (21.0 * Math.random()) + -10;
	int i_3_ = (int) (Math.random() * 21.0) - 10;
	int i_4_ = (int) (41.0 * Math.random()) - 20;
	int i_5_ = (int) (21.0 * Math.random()) - 10;
	for (int i_6_ = 0;
	     ((Class134.aClass67_Sub5_Sub19_Sub1Array2465.length ^ 0xffffffff)
	      < (i_6_ ^ 0xffffffff));
	     i_6_++)
	    Class134.aClass67_Sub5_Sub19_Sub1Array2465[i_6_]
		.method1023(i_4_ + i_3_, i_5_ - -i_4_, i - -i_4_);
	if (arg1 != -7058)
	    method1760(65);
	Class67_Sub5_Sub6.aClass67_Sub5_Sub19Array4547
	    = Class134.aClass67_Sub5_Sub19_Sub1Array2465;
    }
    
    static {
	aRSString_2419 = aRSString_2420;
    }
}
