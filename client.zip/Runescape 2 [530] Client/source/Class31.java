public class Class31
{
    public volatile Object anObject705;
    public volatile int anInt706 = 0;
    public int anInt707;
    public Object anObject708;
    public int anInt709;
    public Class31 aClass31_710;
}
