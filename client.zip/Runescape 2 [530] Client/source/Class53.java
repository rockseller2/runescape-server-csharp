/* Class53 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.util.Calendar;
import java.util.TimeZone;

public class Class53
{
    public static boolean aBoolean1057;
    public static Calendar aCalendar1058;
    public static Class73[] aClass73Array1059;
    public static int anInt1060;
    public static RSString aRSString_1061
	= Class134.method1914("Loading title screen )2 ", (byte) 31);
    public static byte[][][] aByteArrayArrayArray1062;
    public static RSString aRSString_1063;
    public static RSString aRSString_1064;
    public static RSString aRSString_1065;
    public static int anInt1066;
    public static int anInt1067;
    
    public static void method454(int arg0) {
	aRSString_1061 = null;
	if (arg0 != 26513)
	    aRSString_1064 = null;
	aClass73Array1059 = null;
	aRSString_1063 = null;
	aByteArrayArrayArray1062 = null;
	aRSString_1064 = null;
	aRSString_1065 = null;
	aCalendar1058 = null;
    }
    
    static {
	aClass73Array1059 = new Class73[4];
	aRSString_1063 = aRSString_1061;
	aRSString_1065 = Class134.method1914("Loading textures )2 ", (byte) 42);
	aRSString_1064 = aRSString_1065;
	aCalendar1058 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    }
}
