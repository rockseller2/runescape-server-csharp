/* Class67_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class67_Sub3 extends Class67
{
    public int anInt2842;
    public static RSString aRSString_2843;
    public static int anInt2844;
    public static int[] anIntArray2845;
    public int anInt2846;
    public static boolean[] aBooleanArray2847;
    public static int anInt2848;
    public static RSString aRSString_2849 = Class134.method1914("K", (byte) 93);
    public static int anInt2850;
    public static RSString aRSString_2851;
    public static int anInt2852;
    public static int anInt2853;
    public static RSString aRSString_2854;
    public static Class67_Sub5_Sub19 aClass67_Sub5_Sub19_2855;
    
    public static int method815(int arg0) {
	anInt2850++;
	if (arg0 != 0)
	    anInt2844 = 93;
	return Class67_Sub17.anInt3104;
    }
    
    public static void method816(int arg0) {
	anIntArray2845 = null;
	if (arg0 == 31926) {
	    aBooleanArray2847 = null;
	    aRSString_2854 = null;
	    aClass67_Sub5_Sub19_2855 = null;
	    aRSString_2843 = null;
	    aRSString_2851 = null;
	    aRSString_2849 = null;
	}
    }
    
    public Class67_Sub3(int arg0, int arg1) {
	anInt2842 = arg0;
	anInt2846 = arg1;
    }
    
    static {
	anInt2844 = 0;
	aRSString_2843 = Class134.method1914("T", (byte) 76);
	aRSString_2854 = aRSString_2849;
	anInt2852 = 0;
	aRSString_2851 = aRSString_2849;
    }
}
