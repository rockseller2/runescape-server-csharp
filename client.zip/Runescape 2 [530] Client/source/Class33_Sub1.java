public class Class33_Sub1 extends Class33
{
    public long aLong2763 = System.nanoTime();
    
    public void method295(byte arg0) {
	aLong2763 = System.nanoTime();
	int i = -67 / ((arg0 - -79) / 44);
    }
    
    public int method297(byte arg0, int arg1, int arg2) {
	long l = 1000000L * (long) arg1;
	long l_0_ = aLong2763 - System.nanoTime();
	if ((l_0_ ^ 0xffffffffffffffffL) > (l ^ 0xffffffffffffffffL))
	    l_0_ = l;
	if (arg0 < 57)
	    return -35;
	Class67_Sub1_Sub23.method726(-107, l_0_ / 1000000L);
	long l_1_ = System.nanoTime();
	int i;
	for (i = 0; 10 > i && ((i ^ 0xffffffff) > -2 || l_1_ > aLong2763);
	     aLong2763 += 1000000L * (long) arg2)
	    i++;
	if (aLong2763 < l_1_)
	    aLong2763 = l_1_;
	return i;
    }
}
