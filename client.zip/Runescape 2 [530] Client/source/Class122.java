public class Class122
{
    public static Class136 aClass136_2303;
    public static RSString aRSString_2304;
    public static boolean aBoolean2305 = false;
    public static int anInt2306;
    public static int anInt2307;
    public static Class31 aClass31_2308;
    public static Class131_Sub7_Sub2 aClass131_Sub7_Sub2_2309;
    public static RSString aRSString_2310;
    public static RSString aRSString_2311;
    
    public static void method1694(byte arg0) {
	aRSString_2310 = null;
	aRSString_2311 = null;
	aClass136_2303 = null;
	if (arg0 != 101)
	    method1694((byte) 78);
	aClass31_2308 = null;
	aClass131_Sub7_Sub2_2309 = null;
	aRSString_2304 = null;
    }
    
    public static void method1695(int arg0) {
	if (arg0 == (Class67_Sub5_Sub18.anInt4804 ^ 0xffffffff))
	    Class40.method348(arg0 ^ 0x2cda, 25);
	anInt2306++;
    }
    
    static {
	aRSString_2304 = Class134.method1914("gr-Un:", (byte) 39);
	anInt2307 = 64;
	aClass136_2303 = new Class136(4);
	aRSString_2310 = (Class134.method1914
			 ("You can(Wt add yourself to your own friend list)3",
			  (byte) 17));
	aRSString_2311 = aRSString_2310;
    }
}
