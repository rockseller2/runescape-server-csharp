/* Class80_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class80_Sub1 extends Class80
{
    public Class67_Sub5_Sub11 method1425(byte arg0, Class67_Sub5_Sub11 arg1) {
	if (arg0 != 43)
	    return null;
	return new Class67_Sub5_Sub11_Sub1(arg1.method935(true));
    }
}
