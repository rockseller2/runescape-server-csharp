public class Class30
{
    public static Class50 aClass50_692;
    public static int anInt693;
    public static RSString aRSString_694
	= Class134.method1914("mapdots", (byte) 49);
    public static RSString aRSString_695
	= Class134.method1914("::serverjs5drop", (byte) 92);
    public static int anInt696;
    public static RSString aRSString_697;
    public static Class7 aClass7_698;
    public static int anInt699;
    public static int[] anIntArray700 = new int[25];
    public static RSString aRSString_701;
    public static RSString aRSString_702
	= Class134.method1914("glow2:", (byte) 103);
    public static int anInt703;
    public static Class67_Sub5_Sub19[] aClass67_Sub5_Sub19Array704;
    
    public static int method282(boolean arg0, int arg1) {
	anInt696++;
	if (arg0 != false)
	    method283((byte) -99);
	return arg1 >>> -450226232;
    }
    
    public static void method283(byte arg0) {
	aRSString_701 = null;
	aRSString_702 = null;
	aRSString_694 = null;
	aClass67_Sub5_Sub19Array704 = null;
	aClass7_698 = null;
	aRSString_697 = null;
	anIntArray700 = null;
	aRSString_695 = null;
	aClass50_692 = null;
	if (arg0 != 84)
	    aRSString_694 = null;
    }
    
    static {
	aRSString_701 = aRSString_702;
	aRSString_697 = aRSString_702;
	aClass50_692 = new Class50();
    }
}
