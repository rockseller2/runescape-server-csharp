You must put the cache530 folder in your C:\ drive

so it should look like this 

C:\cache530

Then press Run.bat

Make sure the server is running!